// Convo screen, messenger style: bubbles grouped by sender, a tap on a bubble shows its message tools
// (show / more / hidden, same choice as RP), and the composer offers the same quick-reply menu.
// Convo rooms keep the Engine's own memory system; Mari Kit's memory button is RP only.

import { quickButton } from "../lib/quick.js";
import { swipeNav } from "../lib/swipes.js";
import { chatScrolling } from "../lib/scrolling.js";
import { activityStrip, startJob } from "../lib/activity.js";
import { h, icon, dots, I, setChildren } from "../lib/h.js";
import { api } from "../lib/api.js";
import {
  data,
  characterIndex,
  chatTitle,
  chatMeta,
  messageText,
  firstLetter,
  shortTime,
  messageWindow,
} from "../lib/data.js";
import { TOOL_DEFS, toolPlace } from "../lib/prefs.js";
import { toast, errorBox, avatar, avatarStack, olderButton, fitMenus, jumpTo, sheet } from "../lib/ui.js";
import { pickVoice, stripCues, inline } from "../lib/render.js";
import * as tts from "../lib/tts.js";
import { syncVoiceSettings } from "../lib/voice.js";
import { callsAvailable, callScreen, callPrefs } from "../lib/call.js";
import { shownText, translateStickerInput, stickerTokensMatch } from "../lib/translate.js";
import { loadStickers, stickerContent, stickerPicker, stickerLabel, withoutStickerTokens } from "../lib/stickers.js";
import { watchGeneration, stopGeneration } from "../lib/generation.js";
import { attachmentsOf, closeInTime, dayKey, dayLabel, presenceText, timeLabel } from "../lib/convo-bits.js";
import { presenceOf, presenceLine, STATUS_KO } from "../lib/presence.js";
import { activeAutonomy, clearUnread } from "../lib/autonomy.js";
import { runSlash } from "../lib/slash.js";
import {
  GUIDE,
  quickReplies,
  runTool,
  streamGenerate,
  hiddenFromAI,
  toolLabel,
  composerTool,
  slashNote,
} from "../lib/actions.js";

export function convoScreen({ mount, args, go, back }) {
  const chatId = args[0];
  let alive = true;
  let chat = null;
  let index = new Map();
  let group = false; // more than one character in the room
  let messages = [];
  const win = messageWindow(chatId);
  let busy = false;
  let live = null;
  let picked = null;
  let moreOpen = false;
  let quick = [];
  let qrOpen = false;
  let ttsConfig = null;
  let callAudio = false;
  let voiceSet = null;
  let abort = null;
  // The Engine's presence notices: wait = a character typing, or busy/away and answering later (during a
  // generation); offNote = why the last message got no answer (offline, in a Scene), until the next send.
  let wait = null;
  let offNote = null;
  let queued = null;
  let fresh = null; // GET /conversation/status/:chatId statuses (characters' presence), once per open and reply
  let tick = null; // 지금 답하게: { body, ready } runs once the delayed generation has stopped
  let me = null; // the persona's schedule state (Mari Kit 내 일정), when there is one
  let phoneBtn = null;
  let call = null; // the call screen, when the Calls package is installed
  let callPoll = null;
  let ringCheck = null; // looks for a ringing call (calls start from a character's message)
  let auto = null; // Convo autonomy while this chat is open
  let offVisible = () => {};
  let stickers = { list: [], map: new Map(), globals: [] };
  let stickerContext = "";
  let stickerAttempted = false;
  let stickerLoad = null;
  let stickerDialog = null;

  const who = h("span", {
    style: { display: "flex", flexDirection: "column", alignItems: "center", gap: "4px", minWidth: "0" },
  });
  const head = h(
    "header",
    {
      style: {
        flexShrink: "0",
        display: "grid",
        gridTemplateColumns: "96px minmax(0,1fr) 96px",
        alignItems: "center",
        padding: "12px 4px",
        borderBottom: "1px solid var(--line)",
        background: "var(--surface)",
      },
    },
    h(
      "button",
      {
        type: "button",
        class: "ib",
        "aria-label": "대화 목록",
        onClick: () => back("convos"),
      },
      icon(I.back, 22, 1.8),
    ),
    who,
    h(
      "span",
      { style: { display: "flex", justifyContent: "flex-end" } },
      (phoneBtn = h(
        "button",
        { type: "button", class: "ib", "aria-label": "전화 걸기", hidden: true, onClick: () => dial() },
        icon(I.phone, 19, 1.6),
      )),
      h(
        "button",
        {
          type: "button",
          class: "ib",
          "aria-label": "채팅 설정",
          onClick: () => go(`chat-settings/${encodeURIComponent(chatId)}`),
        },
        icon(I.info),
      ),
    ),
  );
  const list = h("div", { class: "cv" });
  const scroller = h("div", { class: "scroll", style: { background: "var(--paper)" } }, list);
  const input = h("textarea", {
    class: "cin",
    rows: 1,
    placeholder: "메시지",
    "aria-label": "메시지",
    onInput: grow,
    onKeydown: (e) => {
      if (e.key === "Enter" && !e.shiftKey && !e.isComposing && matchMedia("(pointer: fine)").matches) {
        e.preventDefault();
        send();
      }
    },
  });
  const qrBtn = h(
    "button",
    {
      type: "button",
      class: "cb",
      "aria-label": "빠른 답장",
      "aria-haspopup": "menu",
      hidden: true,
      onClick: () => {
        qrOpen = !qrOpen;
        drawQuick();
      },
    },
    dots(),
  );
  // The Engine's 보내기 옆 번역 버튼 (chat setting): translates the draft in place.
  const trBtn = h(
    "button",
    {
      type: "button",
      class: "cb",
      "aria-label": "입력 번역",
      hidden: true,
      onClick: async () => {
        const text = input.value.trim();
        if (!text) return;
        trBtn.disabled = true;
        try {
          input.value = await translateStickerInput(text, chatMeta(chat), chatId);
          grow();
        } catch (error) {
          toast(
            error.code === "STICKER_TRANSLATION_CHANGED"
              ? stickerLabel("translationChanged")
              : `번역하지 못했어요: ${error.message}`,
          );
        } finally {
          trBtn.disabled = false;
        }
      },
    },
    icon(I.translate, 16, 1.6),
  );
  const sendBtn = h(
    "button",
    { type: "button", class: "cb send", "aria-label": "보내기", onClick: () => (busy ? stopGenerating() : send()) },
    icon(I.send, 16, 2),
  );
  const stickerBtn = h(
    "button",
    {
      type: "button",
      class: "cb",
      "aria-label": stickerLabel("open"),
      title: stickerLabel("open"),
      "aria-haspopup": "dialog",
      disabled: true,
      onClick: () => {
        if (!chat) return;
        qrOpen = false;
        drawQuick();
        stickerDialog?.close();
        stickerDialog = stickerPicker({
          load: () => refreshStickers(),
          onPick: insertSticker,
          onClose: () => {
            stickerDialog = null;
          },
        });
      },
    },
    icon(
      ["M20 13c0 4.4-3.6 8-8 8H6a3 3 0 0 1-3-3V6a3 3 0 0 1 3-3h11a3 3 0 0 1 3 3z", "M20 13h-4a3 3 0 0 0-3 3v5"],
      18,
      1.6,
    ),
  );
  const quickLayer = h("div");
  const strip = activityStrip();
  const scroll = chatScrolling(scroller);
  mount.append(
    head,
    scroller,
    scroll.anchor,
    quickLayer,
    strip.el,
    h(
      "div",
      { class: "cmp", style: { background: "var(--paper)" } },
      quickButton({
        getChat: () => chat,
        go,
        changed: async () => {
          await load(false);
          await loadMe();
        },
      }),
      stickerBtn,
      input,
      trBtn,
      qrBtn,
      sendBtn,
    ),
  );

  function grow() {
    input.style.height = "auto";
    input.style.height = `${Math.min(input.scrollHeight, 160)}px`;
  }

  function insertSticker(name) {
    const start = input.selectionStart ?? input.value.length;
    const end = input.selectionEnd ?? start;
    const before = input.value.slice(0, start);
    input.setRangeText(`${before && !before.endsWith("\n") ? "\n" : ""}sticker:${name}:\n`, start, end, "end");
    grow();
    input.focus();
  }

  // No polling or asset reads on each reply. History loads the map only when it contains a sticker;
  // opening the picker and changing its library explicitly refresh it.
  function refreshStickers() {
    const context = stickerContext;
    if (stickerLoad?.context === context) return stickerLoad.promise;
    stickerAttempted = true;
    const request = { context, promise: null };
    request.promise = loadStickers(chat, index)
      .then((next) => {
        if (alive && context === stickerContext) {
          stickers = next;
          draw();
        }
        return next;
      })
      .finally(() => {
        if (stickerLoad === request) stickerLoad = null;
      });
    stickerLoad = request;
    return request.promise;
  }

  async function load(first, tail = false) {
    try {
      const [c, chars] = await Promise.all([data.chat(chatId), data.characters(), win.reload(tail)]);
      if (!alive) return;
      chat = c;
      stickerBtn.disabled = false;
      const context = JSON.stringify([chat.personaId, chat.characterIds || []]);
      if (context !== stickerContext) {
        stickerContext = context;
        stickerAttempted = false;
        stickers = { list: [], map: new Map(), globals: [] };
      }
      trBtn.hidden = chatMeta(chat).showInputTranslateButton !== true;
      index = characterIndex(chars);
      group = (chat.characterIds || []).length > 1;
      messages = shown();
      if (first) {
        const [ui, config] = await Promise.all([data.engineUi(), api.get("/tts/config").catch(() => null)]);
        quick = quickReplies(ui, I.guide, "conversation");
        qrBtn.hidden = !quick.length;
        ttsConfig = config?.enabled ? config : null;
        callAudio = config?.callAudioEnabled === true;
        voiceSet = ttsConfig ? await syncVoiceSettings(config) : null;
        const cast = (chat.characterIds || []).map((id) => index.get(id)).filter(Boolean);
        const lead = cast[0];
        const title = chatTitle(chat, index);
        setChildren(
          who,
          cast.length > 1 ? avatarStack(cast, 40) : avatar(lead?.avatar, firstLetter(title), 40),
          h(
            "span",
            {
              style: {
                fontSize: "12px",
                maxWidth: "100%",
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              },
            },
            `${title} ›`,
          ),
        );
        who.style.cursor = lead ? "pointer" : "";
        // One character: their profile. A group: the room's cast in chat settings.
        if (lead)
          who.onclick = () =>
            go(
              cast.length > 1
                ? `chat-settings/${encodeURIComponent(chatId)}`
                : `character/${encodeURIComponent(lead.id)}`,
            );
        loadMe();
        loadPresence();
        // The status line follows the schedule minute by minute, from data already here.
        tick = setInterval(() => document.visibilityState === "visible" && drawPresence(), 60000);
        setupCalls();
        // The Engine's Convo autonomy (characters writing first, exchanges, busy delays) runs in its client;
        // the shell runs the same while this chat is open (lib/autonomy.js).
        auto = activeAutonomy({
          chatId,
          meta: () => chatMeta(chat),
          userStatus: () => presence().userStatus || "active",
          isBusy: () => busy,
          generate: (body) => generate(body),
        });
        if (Number(chatMeta(chat).autonomousUnreadCount) > 0) clearUnread(chatId).then(() => data.chats(true));
        // Opened from a search hit (#/convo/<chat>/<message>): read back to it.
        if (args[1] && (await win.until(args[1]))) messages = shown();
      }
      draw();
      if (first) requestAnimationFrame(() => jumpTo(list, args[1]) || (scroller.scrollTop = scroller.scrollHeight));
    } catch (error) {
      if (alive) setChildren(list, errorBox(error));
    }
  }

  // The user's own schedule (Mari Kit 내 일정): its status goes with every generation (presence()), and its line is
  // at the bottom of the status sheet.
  const SCHED_LABEL = { online: "온라인", idle: "자리 비움", dnd: "방해 금지", offline: "오프라인" };
  async function loadMe() {
    try {
      me = await api.get(`/mari-kit/schedule/chat/${encodeURIComponent(chatId)}`);
    } catch {
      me = null;
    }
    if (alive) drawPresence();
  }

  // The characters' presence (the Engine's status and schedules) under the name; tapping it opens the status sheet,
  // which also holds the user's own schedule line. Computed on screen from the schedule each minute (no request);
  // read fresh from the Engine when the chat opens and after each reply.
  async function loadPresence() {
    try {
      fresh = (await api.get(`/conversation/status/${encodeURIComponent(chatId)}`))?.statuses || null;
    } catch {
      fresh = null;
    }
    if (alive) drawPresence();
  }
  function drawPresence() {
    if (!chat) return;
    who.querySelector(".me-line")?.remove();
    const meta = chatMeta(chat);
    const now = new Date();
    const people = (chat.characterIds || [])
      .map((id) => ({ id, c: index.get(id), p: presenceOf(meta, id, now, fresh?.[id] || null) }))
      .filter((x) => x.c);
    if (!people.length) return;
    let text;
    if (people.length === 1) text = presenceLine(people[0].p) || STATUS_KO[people[0].p?.status || "online"];
    else {
      const shown = people.slice(0, 2).map((x) => `${x.c.name} ${STATUS_KO[x.p?.status || "online"]}`);
      text = `${shown.join(" · ")}${people.length > 2 ? ` 외 ${people.length - 2}` : ""}`;
    }
    who.append(
      h(
        "button",
        {
          type: "button",
          class: "me-line",
          "aria-label": `상태와 일정: ${text}`,
          onClick: (e) => {
            e.stopPropagation();
            openPresence();
          },
        },
        people.slice(0, 3).map((x) => h("span", { class: `sdot ${x.p?.status || "online"}` })),
        h("span", { class: "me-line-t" }, text),
      ),
    );
  }
  // The sheet's code loads only when it is opened (most visits never open it).
  async function openPresence() {
    const { presenceSheet } = await import("../lib/presence-sheet.js");
    if (!alive) return;
    presenceSheet({
      chat,
      index,
      fresh,
      me,
      waiting: busy && wait?.kind === "delayed" ? wait.characterIds || [] : [],
      replyNow,
      go,
      changed: async () => {
        await load(false);
        await loadPresence();
      },
    });
  }
  /** The Engine's own presence fields, so its autonomy sees the user's planned status too. */
  function presence() {
    const n = me?.profile?.config?.enabled ? me.now : null;
    if (!n) return {};
    return {
      userStatus: n.status === "online" ? "active" : n.status === "dnd" ? "dnd" : "idle",
      userActivity: `${SCHED_LABEL[n.status]}; 설정상 현재 일정: ${n.activity}`.slice(0, 120),
    };
  }

  function toolsFor(m) {
    const usable = TOOL_DEFS.filter(
      (t) =>
        !(t.assistantOnly && m.role !== "assistant") &&
        !(t.id === "voice" && (!ttsConfig || !stripCues(withoutStickerTokens(messageText(m))).trim())),
    );
    return {
      shown: usable.filter((t) => toolPlace(t) === "show"),
      more: usable.filter((t) => toolPlace(t) === "more"),
    };
  }

  // An ended call stays in the conversation as one line (통화 설정 › 대화에 통화 대사 남기기).
  function callEvent(m) {
    if (m.role !== "system") return null;
    let extra = m.extra;
    try {
      if (typeof extra === "string") extra = JSON.parse(extra);
    } catch {}
    const ev = extra?.conversationCallEvent;
    return ev?.callId && ev.status === "ended" ? ev : null;
  }
  function shown() {
    const keepCalls = callPrefs().log;
    // System lines (dice, notices, other call states) show like the Engine's; an ended call only when kept.
    return win.list.filter((m) => m.role !== "system" || (callEvent(m) ? keepCalls : !!messageText(m).trim()));
  }

  async function setupCalls() {
    const first = await callsAvailable(chatId);
    if (!first || !alive) return;
    call = callScreen({
      chatId,
      chat,
      index,
      ttsConfig,
      mount,
      go,
      onEnded: async () => {
        await load();
        scroller.scrollTop = scroller.scrollHeight;
      },
    });
    phoneBtn.hidden = false;
    const ring = (st) => {
      const s = st?.activeCall || st?.ringingCall;
      if (s && alive && !call.session) call.open(s);
    };
    // A character can only ring under the package's own rules (call command on, call audio on); while it cannot,
    // or the page is in the background, there is nothing to watch for.
    const canRing = () => {
      const m = chatMeta(chat);
      return callAudio && m.characterCommands !== false && m.conversationCommandToggles?.call !== false;
    };
    const check = async () => {
      if (!alive || call.session || document.visibilityState !== "visible" || !canRing()) return;
      try {
        ring(await api.get(`/conversation-calls/chat/${encodeURIComponent(chatId)}/status`));
      } catch {}
    };
    ring(first);
    ringCheck = check;
    // A character rings from a message, which this screen sees arrive (checked right after each reply); the slow
    // fallback covers a call started elsewhere. Each check is a request with about 1.4KB of headers.
    callPoll = setInterval(check, 30000);
    document.addEventListener("visibilitychange", check);
    offVisible = () => document.removeEventListener("visibilitychange", check);
  }
  async function dial() {
    if (!call) return;
    if (chatMeta(chat).conversationCallsEnabled !== true || !callAudio) {
      toast(
        callAudio
          ? "이 방은 통화가 꺼져 있어요 · 통화 설정에서 켜 주세요"
          : "통화 음성이 꺼져 있어요 · 통화 설정에서 켜 주세요",
      );
      return go(`call-settings/${encodeURIComponent(chatId)}`);
    }
    try {
      call.open(await api.post("/conversation-calls/start", { chatId, mode: "audio", initiator: "user" }));
    } catch (error) {
      toast(`걸지 못했어요: ${error.message}`);
    }
  }

  function draw() {
    if (!chat) return;
    if (!stickerAttempted && messages.some((m) => /sticker:[a-z0-9_]+:/.test(messageText(m))))
      refreshStickers().catch(() => {}); // A failed read leaves the token visible; the picker offers retry.
    const items = [];
    if (win.more) items.push(olderButton(win, scroller, () => ((messages = shown()), draw())));
    // Like the Engine's Convo, a blank line starts a new bubble.
    const meta = chatMeta(chat);
    const bubbles = [];
    for (const m of messages) {
      const ev = callEvent(m);
      if (ev) {
        bubbles.push({ m, ev, me: null, first: true, last: true });
        continue;
      }
      // System and narrator lines (dice, notices) sit in the middle like the Engine's cards.
      if (m.role === "system" || m.role === "narrator") {
        bubbles.push({ m, sys: true, text: messageText(m).trim(), me: null, first: true, last: true });
        continue;
      }
      const original = m.role === "assistant" ? stripCues(messageText(m)) : messageText(m);
      let { main, sub } = shownText(m, meta, original);
      if (!stickerTokensMatch(original, main)) {
        // A saved translation may drop media tokens. Keep the original image and show the translation below it.
        sub = main;
        main = original;
      }
      const split = (t) =>
        t
          .split(/\n{2,}/)
          .map((p) => p.trim())
          .filter(Boolean);
      const parts = split(main);
      // The translation goes under the bubble it belongs to: piece by piece when it has as many pieces,
      // otherwise all of it under the last bubble.
      let subs = split(sub);
      if (subs.length !== parts.length && parts.length > 1)
        subs = sub
          .split(/\n+/)
          .map((p) => p.trim())
          .filter(Boolean);
      const each = parts.length > 1 && subs.length === parts.length;
      const atts = attachmentsOf(m);
      if (!parts.length && atts.length) {
        bubbles.push({ m, text: "", media: true, me: m.role === "user", first: true, last: true, sub });
        continue;
      }
      (parts.length ? parts : [""]).forEach((text, k, all) =>
        bubbles.push({
          m,
          text,
          me: m.role === "user",
          first: k === 0,
          last: k === all.length - 1,
          sub: each ? subs[k] : k === all.length - 1 ? sub : "",
        }),
      );
    }
    const lastReplyId = [...messages].reverse().find((m) => m.role === "assistant")?.id;
    let lastDay = "";
    bubbles.forEach((bub, i) => {
      const { m, me } = bub;
      // A line with the day whenever the day changes (오늘, 어제, 11월 12일 목요일), like the Engine.
      const day = dayKey(m.createdAt);
      if (bub.first && day && day !== lastDay) {
        lastDay = day;
        items.push(h("div", { class: "daysep", role: "separator" }, h("span", null, dayLabel(m.createdAt))));
      }
      if (bub.ev) {
        items.push(
          h(
            "button",
            { type: "button", class: "callev", onClick: () => call?.logSheet(bub.ev.callId) },
            icon(I.phone, 13, 1.8),
            `음성 통화 · ${shortTime(m.createdAt)}`,
            h("span", null, "대사 보기 ›"),
          ),
        );
        return;
      }
      const prev = bubbles[i - 1];
      const next = bubbles[i + 1];
      // A run is one speaker's bubbles in a row: in a group, another character starts a new run.
      // Like the Engine, a run also ends after 5 minutes or at a new day.
      const sameRun = (o) =>
        o &&
        !o.ev &&
        !o.sys &&
        !bub.sys &&
        o.me === me &&
        (me || o.m.characterId === m.characterId) &&
        closeInTime(o.m.createdAt, m.createdAt);
      const firstOfRun = !sameRun(prev);
      const lastOfRun = !sameRun(next);
      const radius = me
        ? `18px ${firstOfRun ? "18px" : "6px"} ${lastOfRun ? "18px" : "6px"} 18px`
        : `${firstOfRun ? "18px" : "6px"} 18px 18px ${lastOfRun ? "18px" : "6px"}`;
      const on = picked === m.id;
      const speaker = group && !me && !bub.sys ? index.get(m.characterId) : null;
      const wrap = h(
        "div",
        {
          class: [group && !me && !bub.sys ? "who" : "", hiddenFromAI(m) ? "hid" : ""].join(" ").trim() || null,
          "data-message-id": bub.first ? m.id : null,
          style: {
            display: "flex",
            flexDirection: "column",
            alignItems: bub.sys ? "center" : me ? "flex-end" : "flex-start",
            marginTop: i === 0 ? "0" : firstOfRun ? "24px" : bub.first ? "14px" : "10px",
          },
        },
        speaker && firstOfRun ? avatar(speaker.avatar, speaker.name?.[0] || "·", 28) : null,
        speaker && firstOfRun ? h("span", { class: "who-name" }, speaker.name) : null,
        bub.media
          ? null
          : h(
              "button",
              {
                type: "button",
                class: bub.sys ? `sysmsg${on ? " on" : ""}` : `bub ${me ? "me" : "them"}${on ? " on" : ""}`,
                style: bub.sys ? null : { borderRadius: radius },
                "aria-expanded": on ? "true" : "false",
                onClick: (e) => {
                  e.stopPropagation();
                  picked = on ? null : m.id;
                  moreOpen = false;
                  draw();
                },
              },
              bub.sys ? inline(bub.text) : stickerContent(bub.text, stickers.map),
            ),
        bub.sub ? h("span", { class: "bub-tr" }, stickerContent(bub.sub, stickers.map)) : null,
        bub.last && !bub.sys ? mediaOf(m, me) : null,
        // The time under the last bubble of a run (one speaker within 5 minutes).
        lastOfRun && bub.last && !bub.sys ? h("span", { class: "btime" }, timeLabel(m.createdAt)) : null,
      );
      // Other replies to this turn: always under the newest reply (› there asks for a new one), else when tapped.
      const newest = m.id === lastReplyId;
      if (bub.last && m.role === "assistant" && (newest || (on && (m.swipeCount || 1) > 1)))
        wrap.append(
          swipeNav({
            chatId,
            message: m,
            reload: () => load(),
            regenerate: newest ? () => generate({ regenerateMessageId: m.id }) : null,
            busy,
          }),
        );
      if (on && bub.last) {
        const { shown, more } = toolsFor(m);
        wrap.append(
          h(
            "div",
            {
              role: "toolbar",
              "aria-label": "메시지 도구",
              style: {
                position: "relative",
                display: "flex",
                marginTop: "6px",
                marginLeft: me ? "0" : "-10px",
                marginRight: me ? "-10px" : "0",
              },
            },
            shown.map((t) =>
              h(
                "button",
                {
                  type: "button",
                  class: "ma",
                  "aria-label": toolLabel(t, m),
                  title: toolLabel(t, m),
                  onClick: (e) => {
                    e.stopPropagation();
                    tool(t.id, m);
                  },
                },
                icon(t.icon, 15, 1.6),
              ),
            ),
            more.length
              ? h(
                  "button",
                  {
                    type: "button",
                    class: "ma",
                    "aria-label": "더보기",
                    "aria-expanded": moreOpen ? "true" : "false",
                    onClick: (e) => {
                      e.stopPropagation();
                      moreOpen = !moreOpen;
                      draw();
                    },
                  },
                  dots(15),
                )
              : null,
            moreOpen
              ? h(
                  "div",
                  { class: "tmenu", role: "menu", style: { [me ? "right" : "left"]: "0", top: "40px" } },
                  more.map((t) =>
                    h(
                      "button",
                      {
                        type: "button",
                        role: "menuitem",
                        onClick: (e) => {
                          e.stopPropagation();
                          moreOpen = false;
                          tool(t.id, m);
                        },
                      },
                      h("span", { style: { display: "flex", color: "var(--ink-2)" } }, icon(t.icon, 16, 1.6)),
                      toolLabel(t, m),
                    ),
                  ),
                )
              : null,
          ),
        );
      }
      items.push(wrap);
    });
    if (busy && !live && wait) items.push(waitRow());
    else if (busy) {
      const parts = String(live || "")
        .split(/\n{2,}/)
        .map((p) => p.trim())
        .filter(Boolean);
      (parts.length ? parts : ["…"]).forEach((text, k) =>
        items.push(
          h(
            "div",
            { style: { display: "flex", marginTop: k === 0 ? "24px" : "10px" } },
            h("span", { class: "bub them", style: { cursor: "default" } }, stickerContent(text, stickers.map)),
          ),
        ),
      );
    }
    if (offNote && !busy) items.push(h("div", { class: "pnote", role: "status" }, presenceText(offNote)));
    if (!messages.length && !busy) items.push(h("div", { class: "empty" }, "첫 메시지를 보내 보세요."));
    setChildren(list, items);
    setChildren(sendBtn, icon(busy ? I.stop : I.send, busy ? 14 : 16, 2));
    sendBtn.setAttribute("aria-label", busy ? "멈춤" : "보내기");
    fitMenus(list);
  }

  // Attachments under a message: a character's selfies and videos, pictures the user sent.
  function mediaOf(m, me) {
    const atts = attachmentsOf(m);
    if (!atts.length) return null;
    return h(
      "div",
      { class: `att ${me ? "me" : "them"}` },
      atts.map((a) =>
        a.kind === "video"
          ? h("video", {
              class: "att-v",
              src: a.src,
              controls: true,
              playsinline: true,
              preload: "metadata",
              title: a.prompt,
              onLoadedmetadata: (e) => {
                const gap = scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight;
                if (gap <= e.currentTarget.offsetHeight + 120) scroller.scrollTop = scroller.scrollHeight;
              },
            })
          : a.kind === "image"
            ? h(
                "button",
                {
                  type: "button",
                  class: "att-i",
                  "aria-label": a.prompt ? `사진: ${a.prompt.slice(0, 60)}` : "사진 크게 보기",
                  onClick: (e) => {
                    e.stopPropagation();
                    viewImage(a, m);
                  },
                },
                h("img", {
                  src: a.thumb,
                  alt: a.prompt || "",
                  loading: "lazy",
                  decoding: "async",
                  // A picture grows the chat when it arrives: a reader who was at the bottom stays there.
                  onLoad: (e) => {
                    const gap = scroller.scrollHeight - scroller.scrollTop - scroller.clientHeight;
                    if (gap <= e.currentTarget.offsetHeight + 120) scroller.scrollTop = scroller.scrollHeight;
                  },
                }),
              )
            : h("span", { class: "att-f" }, a.name),
      ),
    );
  }
  function viewImage(a, m) {
    const s = sheet(
      h(
        "div",
        { class: "att-view" },
        h("img", { src: a.src, alt: a.prompt || "" }),
        a.prompt ? h("p", { class: "hint" }, a.prompt) : null,
        h(
          "div",
          { style: { display: "flex", gap: "8px", flexWrap: "wrap" } },
          h(
            "button",
            {
              type: "button",
              class: "pill",
              onClick: () => {
                s.close();
                picked = m.id;
                moreOpen = false;
                draw();
              },
            },
            "메시지 도구",
          ),
          h("button", { type: "button", class: "pill", onClick: () => s.close() }, "닫기"),
        ),
      ),
      { label: "사진" },
    );
  }
  // While a character is typing, or busy/away and answering later (the Engine waits on the same request).
  function waitRow() {
    // A typing notice carries names only; find their faces by name among the room's characters.
    const cast = (chat?.characterIds || []).map((id) => index.get(id)).filter(Boolean);
    const faces = wait.characterIds?.length
      ? wait.characterIds.map((id) => index.get(id)).filter(Boolean)
      : (wait.names || []).map((n) => cast.find((c) => c.name === n)).filter(Boolean);
    const names = wait.characterIds?.length
      ? wait.characterIds.map((id) => index.get(id)?.name).filter(Boolean)
      : wait.names;
    const info = { ...wait, names: names?.length ? names : wait.names };
    return h(
      "div",
      { class: `pwait ${wait.kind}`, role: "status" },
      faces.length > 1
        ? avatarStack(faces, 24)
        : faces[0]
          ? avatar(faces[0].avatar, faces[0].name?.[0] || "·", 24)
          : null,
      h(
        "span",
        { class: "pwait-t" },
        presenceText(info),
        wait.kind === "typing" ? h("span", { class: "tdots" }, h("i"), h("i"), h("i")) : null,
      ),
      wait.kind === "delayed" && wait.characterIds?.length === 1
        ? h("button", { type: "button", class: "pill", onClick: () => replyNow(wait.characterIds[0]) }, "지금 답하게")
        : null,
    );
  }
  // The Engine's Reply now: stop the delayed generation and ask that character again without the delay.
  function replyNow(characterId) {
    if (queued) return;
    queued = { body: { forCharacterId: characterId, skipPresenceDelay: true }, ready: null };
    abort?.abort();
    queued.ready = stopGeneration(chatId).catch(() => {});
  }

  function drawQuick() {
    setChildren(
      quickLayer,
      qrOpen
        ? [
            h("button", {
              type: "button",
              class: "scrim",
              style: { background: "transparent" },
              "aria-label": "닫기",
              onClick: () => {
                qrOpen = false;
                drawQuick();
              },
            }),
            h(
              "div",
              { class: "qr", role: "menu", "aria-label": "빠른 답장", style: { zIndex: "22" } },
              quick.map((q) =>
                h(
                  "button",
                  {
                    type: "button",
                    role: "menuitem",
                    disabled: busy,
                    onClick: () => {
                      qrOpen = false;
                      drawQuick();
                      runQuick(q);
                    },
                  },
                  h(
                    "span",
                    {
                      style: {
                        display: "flex",
                        justifyContent: "center",
                        fontSize: "16px",
                        lineHeight: "1",
                        color: "var(--ink-2)",
                      },
                    },
                    q.icon ? icon(q.icon, 17, 1.6) : q.emoji,
                  ),
                  h("span", null, q.label),
                ),
              ),
            ),
          ]
        : [],
    );
  }

  /** One message as a speak request: tag-capable voices read the cues inline, others get the first as a tone. */
  function messageRequest(m) {
    const raw = messageText(m);
    const speech = withoutStickerTokens(raw);
    const voice = pickVoice(ttsConfig, m.characterId);
    const speaker = index.get(m.characterId)?.name;
    const tags = voiceSet?.cueResolved === "tags";
    const lead = /^\s*\[([^\]\n]{1,80})\]\s*/.exec(speech);
    const text = tags ? speech : stripCues(speech);
    return {
      key: tts.hashKey([m.id, m.activeSwipeIndex ?? 0, raw, voice, ttsConfig?.source, ttsConfig?.model]),
      body: {
        text,
        ...(speaker ? { speaker } : {}),
        ...(voice ? { voice } : {}),
        ...(!tags && lead ? { tone: lead[1].trim() } : {}),
      },
    };
  }

  async function speakMessage(m) {
    const req = messageRequest(m);
    if (!stripCues(req.body.text).trim()) return;
    if (tts.activeLine() === req.key) return tts.stop();
    await tts.speak(req.key, req.body);
  }

  // Other replies to the same turn (the Engine's swipes): shown under a tapped message that has them.

  function tool(id, m) {
    picked = null;
    draw();
    return runTool(id, { chatId, chat, message: m, reload: load, generate, go, speak: speakMessage });
  }

  /** Runs one generation; resolves true when a message was saved (autonomy needs to know). */
  async function generate(body) {
    if (busy) return false;
    let produced = false;
    busy = true;
    live = "";
    wait = null;
    offNote = null;
    draw();
    scroller.scrollTop = scroller.scrollHeight;
    abort = new AbortController();
    const done = body?.autonomous
      ? () => {}
      : startJob("답장 쓰는 중…", { label: "멈추기", fn: () => stopGenerating() });
    try {
      await streamGenerate({
        chatId,
        body: { ...presence(), ...body },
        signal: abort.signal,
        onToken: (text) => {
          if (!alive) return;
          wait = null;
          // Follow the new text only for a reader at the bottom (someone reading older messages stays put).
          const follow = scroll.nearBottom();
          live = text;
          draw();
          if (follow) scroller.scrollTop = scroller.scrollHeight;
        },
        onPresence: (info) => {
          if (!alive || body?.autonomous) return;
          if (info.kind === "offline") offNote = info;
          else wait = info;
          draw();
        },
        onSaved: (saved) => {
          if (saved) produced = true;
          if (!alive || !saved) return;
          messages.push(saved);
          live = "";
          draw();
        },
      });
    } catch (error) {
      // A character's own (autonomous) message failing is not the user's error to see.
      if (error.name !== "AbortError" && !body?.autonomous) toast(`생성하지 못했어요: ${error.message}`);
    } finally {
      done();
      busy = false;
      live = null;
      wait = null;
      abort = null;
      if (alive) {
        const before = new Set(messages.map((m) => m.id));
        const follow = scroll.nearBottom();
        await load(false, true);
        loadPresence();
        ringCheck?.();
        if (follow) scroller.scrollTop = scroller.scrollHeight;
        // 자동 재생: the character messages this turn added, in order.
        if (ttsConfig && voiceSet?.convo && voiceSet.autoplay !== "off")
          tts.speakSequence(
            messages
              .filter((m) => m.role === "assistant" && !before.has(m.id))
              .map(messageRequest)
              .filter((request) => stripCues(request.body.text).trim()),
          );
        await recovery.check();
        if (queued) {
          const next = queued;
          queued = null;
          await next.ready;
          if (alive) return generate(next.body);
        }
      }
    }
    return produced;
  }

  async function stopGenerating() {
    try {
      await stopGeneration(chatId);
      abort?.abort();
      await recovery.check();
    } catch (error) {
      toast(`중단하지 못했어요: ${error.message}`);
    }
  }

  async function send() {
    let text = input.value.trim();
    if (busy) return;
    // Nothing typed: like the Engine, the character goes on (a reply without a new message of mine).
    if (!text) return generate({});
    input.value = "";
    grow();
    if (text.startsWith("/")) return slash(text);
    // The Engine's 내 메시지 번역: the message goes out translated; if that fails, it goes out as written.
    if (chatMeta(chat).translateInput === true)
      text = await translateStickerInput(text, chatMeta(chat), chatId).catch((error) => {
        toast(
          error.code === "STICKER_TRANSLATION_CHANGED"
            ? stickerLabel("translationChanged")
            : "번역하지 못해서 원문으로 보냈어요",
        );
        return text;
      });
    auto?.userSent();
    generate({ userMessage: text });
  }

  async function slash(text) {
    try {
      const note = await runSlash(text, {
        chatId,
        chat,
        messages,
        characters: (chat?.characterIds || [])
          .map((id) => ({ id, name: index.get(id)?.name || "" }))
          .filter((c) => c.name),
        generate,
        reload: load,
      });
      slashNote(note, chatId);
    } catch (error) {
      toast(error.message);
    }
  }

  function runQuick(q) {
    if (q.id === "guide") {
      const text = input.value.trim();
      if (!text) return toast("방향을 먼저 적어 주세요");
      input.value = "";
      grow();
      return generate({
        userMessage: null,
        smartResponse: true,
        generationGuide: GUIDE(text),
        generationGuideSource: "guide",
      });
    }
    if (composerTool(q, { chatId, input, grow, slash })) return;
    if (q.content.startsWith("/")) return slash(q.content);
    generate({ userMessage: q.content });
  }

  list.addEventListener("click", () => {
    if (picked) {
      picked = null;
      moreOpen = false;
      draw();
    }
  });
  const off = tts.onTts(() => {});
  let recoveredJob = null;
  const recovery = watchGeneration(chatId, {
    isAttached: () => !!abort,
    onState: (state) => {
      busy = state?.active === true;
      if (busy && !recoveredJob)
        recoveredJob = startJob("이 채팅에서 생성 중…", { label: "멈추기", fn: stopGenerating });
      if (!busy) {
        recoveredJob?.();
        recoveredJob = null;
      }
      draw();
    },
    onSettled: () => load(false, true),
  });
  load(true);
  return {
    dispose: () => {
      strip.dispose();
      scroll.dispose();
      alive = false;
      stickerDialog?.close();
      recovery.dispose();
      recoveredJob?.();
      off();
      tts.stop();
      abort?.abort();
      clearInterval(callPoll);
      clearInterval(tick);
      auto?.stop();
      offVisible();
      call?.dispose();
    },
    onPrefs: draw,
  };
}
